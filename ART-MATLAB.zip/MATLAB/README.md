# ART in MATLAB

----------

----------

- ART is available in MATLAB by [Python Libraries](https://www.mathworks.com/help/matlab/call-python-libraries.html)

- Visit [here](https://github.com/sepandhaghighi/art/blob/master/INSTALL.md#matlab) for installation guide

- ⚠️ There is no need to use `chr_ignore` flag in `tprint`,`text2art` and `tsave` functions
	- Unsupported characters (out of 95 printable characters) will be displayed by a question mark (`?`)